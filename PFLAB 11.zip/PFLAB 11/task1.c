#include <stdio.h>

struct gift
{
    char name[20], type;
    int price, quantity;
};


void highest_price(struct gift gifts[]){
    int max = gifts[0].price, index = 0;

    for (int i = 1; i < 2; i++)
    {
        if (gifts[i].price > max)
        {
            max = gifts[i].price;
            index = i;
        }
        
    }

    printf("The toy with most price is %s", gifts[index].name);
    
}


int main(){
    
    struct gift gifts[2];

    // taking input 
    for (int i = 0; i < 2; i++)
    {
        printf("Enter name: ");
        scanf("%s", gifts[i].name);
        getchar();

        printf("Enter type: ");
        scanf("%c", &gifts[i].type);

        printf("Enter price: ");
        scanf("%d", &gifts[i].price);

        printf("Enter quantity: ");
        scanf("%d", &gifts[i].quantity);
    }
    
    highest_price(gifts);

    return 0;
}