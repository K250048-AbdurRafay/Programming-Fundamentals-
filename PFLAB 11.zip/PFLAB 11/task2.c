#include <stdio.h>


void display_days(int day){
    if(day <= 0){
        printf("Todays The Day!!\n");
        return;
    }

    printf("Days left: %d\n", day);
    return display_days(day-1);
}


int main(){
    char events[3][20];
    int days[3];

    for (int i = 0; i < 3; i++)
    {
        printf("Enter events name: ");
        scanf("%s", events[i]);

        printf("Enter days left: ");
        scanf("%d", &days[i]);
    }
    
    display_days(10);
    return 0;
}