#include <stdio.h>

struct employee
{   
    char name[20], id[2];
    int present;
};

void employee_attedance(struct employee emp[]){
    char name[20];
    printf("Enter name: ");
    scanf("%s", &name);

    for (int i = 0; i < 2; i++)
    {
        if (name == emp[i].name)
        {
            emp[i].present += 1;
        }
        
    }
    
}

void t_attendance(struct employee emp[], int index, int total){
    if (index > 2)
    {
        printf("total attendance: %d", total);
        return;
    }

    total += emp[index].present;
    t_attendance(emp, index += 1, total);
    
}

int main(){
    struct employee employees[2];

    for (int i = 0; i < 2; i++)
    {
        printf("Enter name: ");
        scanf("%s", employees[i].name);

        printf("Enter id: ");
        scanf("%s", employees[i].id);

        employees[i].present = 0;
    }
    

    return 0;
}