#include <stdio.h>

void calculateFuel(int fuel, int consumption, int recharge, int solarBonus, int planet, int totalPlanets){

    if (planet > totalPlanets)
    {
        printf("Destination Reached\n");
        return;
    }
    else if (fuel == 0)
    {
        printf("Fuel finished air craft cant reach destination\n");
        return;
    }


    fuel -= consumption;
    if (fuel <=0){fuel = 0;}

    if ((planet % 4) == 0)
    {
        fuel += solarBonus;}
    
    fuel += recharge;
    
    printf("Planet %d: Fuel Remaining = %d", planet, fuel);


    return calculateFuel(fuel, consumption, recharge, solarBonus, planet+1, totalPlanets);
    
    

}



int main() {
    int fuel, consumption, recharge, solarBonus, totalPlanets;

    printf("Enter fuel: ");
    scanf("%d", &fuel);

    printf("Enter fuel consumption per planet: ");
    scanf("%d", &consumption);

    printf("Enter gravitational recharge amount: ");
    scanf("%d", &recharge);

    printf("Enter solar bonus for every fourth palnet: ");
    scanf("%d", &solarBonus);

    printf("Enter total number of planets: ");
    scanf("%d", &totalPlanets);

    printf("\n---- Fuel Report ----\n");

    calculateFuel(fuel, consumption, recharge, solarBonus, 1, totalPlanets);

    return 0;
}
