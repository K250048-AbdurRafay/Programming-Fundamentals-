#include <stdio.h>

typedef struct {
    int id;
    int popularity;
} Book;

int main() {
    int capacity, Q;
    scanf("%d %d", &capacity, &Q);

    Book shelf[1000];
    int count = 0;

    while (Q--) {

        char cmd[10];
        scanf("%s", cmd);

        if (cmd[0] == 'A' && cmd[1] == 'D') {
            int x, y;
            scanf("%d %d", &x, &y);

            int pos = -1;
            
            for (int i = 0; i < count; i++)
                if (shelf[i].id == x)
                    pos = i;

            if (pos != -1) {

                shelf[pos].popularity = y;
                Book temp = shelf[pos];

                for (int i = pos; i < count - 1; i++)
                    shelf[i] = shelf[i + 1];
                shelf[count - 1] = temp;
            }
            else {

                if (count == capacity) {
                    for (int i = 0; i < count - 1; i++)
                        shelf[i] = shelf[i + 1];
                    count--;
                }

                shelf[count].id = x;
                shelf[count].popularity = y;
                count++;
            }
        }

        else if (cmd[0] == 'A' && cmd[1] == 'C') {
            int x;
            scanf("%d", &x);

            int pos = -1;

            for (int i = 0; i < count; i++)
                if (shelf[i].id == x)
                    pos = i;

            if (pos == -1)
                printf("-1\n");

            else {
                printf("%d\n", shelf[pos].popularity);
                Book temp = shelf[pos];

                for (int i = pos; i < count - 1; i++)
                    shelf[i] = shelf[i + 1];
                shelf[count - 1] = temp;
            }
        }
    }

    return 0;
}
