#include <stdio.h>


void calculateRepayment(double loan, double interestRate, int years, int yearcount, double installment){
    // base case 
    if (loan <= 0 || years == 0)
    {
        
        return;
    }
    
    
    loan = loan - installment;
    if (loan < 0){loan = 0;}

    loan = loan + (interestRate*loan);

    printf("Year %d: Remaining Loan = %.2f\n", yearcount, loan);
    return calculateRepayment(loan, interestRate, years - 1, yearcount + 1, installment);
    
}




int main(){
    

    double loan, interestRate, installment;
    int years;

    printf("Enter loan amount: ");
    scanf("%lf", &loan);

    printf("Enter interest rate (ex: 0.10 for 10%%): ");
    scanf("%lf", &interestRate);

    printf("Enter number of years: ");
    scanf("%d", &years);

    printf("Enter installment amount: ");
    scanf("%lf", &installment);

    printf("\n--- Repayment ---\n");
    calculateRepayment(loan, interestRate, years, 1, installment);




    return 0;
}