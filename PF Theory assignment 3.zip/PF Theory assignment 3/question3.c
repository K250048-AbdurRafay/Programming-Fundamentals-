#include <stdio.h>
#include <string.h>

struct Employee
{
    char name[20], id[3], designation[10];
    int salary;
};

void display_employees(struct Employee employees[]){
    char name[20], id[3], designation[10];
    int salary;

    printf("Name ----- Id ----- Designation ----- Salary\n");

    for (int i = 0; i < 2; i++)
    {
        strcpy(name, employees[i].name);
        strcpy(id, employees[i].id);
        strcpy(designation, employees[i].designation);
        salary = employees[i].salary;

        printf("%s ----- %s ----- %s ----- %d\n", name, id, designation, salary);
    }
}

void highestsalary(struct Employee employees[]){

    int max = employees[0].salary;
    int index = 0;

    for (int i = 0; i < 2; i++)
    {
        if (employees[i].salary > max)
        {
            max = employees[i].salary;
            index = i;
        }
        
    }
    
    printf("Person with highest salary\n");
    printf("Name ----- Id ----- Designation ----- Salary\n");
    printf("%s ----- %s ----- %s ----- %d\n", employees[index].name, employees[index].id, employees[index].designation, employees[index].salary);


}

int main(){

    struct Employee employees[2];

    // taking input 
    for (int i = 0; i < 2; i++)
    {
        printf("Enter name: ");
        scanf("%s", employees[i].name);

        printf("Enter id: ");
        scanf("%s", employees[i].id);

        printf("Enter designation: ");
        scanf("%s", employees[i].designation);

        printf("Enter salary: ");
        scanf("%d", &employees[i].salary);
    }
    
    display_employees(employees);
    printf("\n\n");
    highestsalary(employees);
    return 0;
}


// EXPLAINATION FOR GIVING BONUS:
// we can paas the structure array to a new function that iterates through
// the whole array and whosoever has salary less than 50k gets a 10 percent
// bonus.