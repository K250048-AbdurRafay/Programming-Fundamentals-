#include <stdio.h>
#include <stdlib.h>
#include <string.h>

void add_line(char ***lines, char *text, int *capacity, int *count){
    // if max number of lines reacher then increase size of lines arrray
    if((*count) == (*capacity)){

        (*capacity) *= 2;
        *lines = realloc(*lines, (*capacity) * sizeof(char*));
    }

    (*lines)[*count] = malloc(strlen(text)+1);
    strcpy((*lines)[*count], text);

    (*count)++;

}






void insert_line(char ***lines, char *text, int *capacity, int *count, int index){
    char * temp;
    // if max number of lines reacher then increase size of lines arrray
    if((*count) == (*capacity)){

        (*capacity) *= 2;
        *lines = realloc(*lines, (*capacity) * sizeof(char*));
    }

    // shift thee pointers to make space
    for (int i = *count; i > index; i--) {
        (*lines)[i] = (*lines)[i - 1];
    }

    (*lines)[index] = malloc(strlen(text)+1);
    strcpy((*lines)[index], text);
    (*count)++;

}



void deleteline(char ***lines, int index, int* count, int *capacity){

    free((*lines)[index]);

    // shift pointers 
    for (int i = index; i < *count - 1; i++)
    {
        (*lines)[i] = (*lines)[i+1];}

    (*count)--;


    // Shrink to fit
    *capacity = *count;

    char **lines = realloc(*lines, sizeof(char*) * (*capacity));
}


void print_all_lines(char ***lines, int count){

    for (int i = 0; i < count; i++)
    {
        printf("%d. %s\n", i+1, (*lines)[i]);
    }
    

}

void insert_to_file(char ** lines, int count, char *fptr){
    for (int i = 0; i < count; i++)
    {
        fprintf(fptr, lines[i]);
    }
    
}




int main(){

    int capacity = 5;
    int count = 0;

    char **lines = malloc(capacity * sizeof(char*));

    int choice;
    char text[256];
    int index;

    while (1) {

        printf("\n===== TEXT EDITOR MENU =====\n");
        printf("1. Add line (append at end)\n");
        printf("2. Insert line at index\n");
        printf("3. Delete line\n");
        printf("4. Print all lines\n");
        printf("5. Save all lines to file (append)\n");
        printf("6. Exit\n");
        printf("Enter choice: ");
        scanf("%d", &choice);
        getchar(); // clear newline for fgets

        switch (choice) {

            case 1:
                printf("Enter text: ");
                fgets(text, sizeof(text), stdin);
                text[strcspn(text, "\n")] = '\0';  // remove newline

                add_line(&lines, text, &capacity, &count);
                printf("Line added!\n");
                break;


            case 2:
                printf("Enter index to insert at (0-%d): ", count);
                scanf("%d", &index);
                getchar();

                if (index < 0 || index > count) {
                    printf("Invalid index!\n");
                    break;
                }

                printf("Enter text: ");
                fgets(text, sizeof(text), stdin);
                text[strcspn(text, "\n")] = '\0';

                insert_line(&lines, text, &capacity, &count, index);
                printf("Line inserted!\n");
                break;


            case 3:
                printf("Enter index to delete (0-%d): ", count - 1);
                scanf("%d", &index);
                getchar();

                if (index < 0 || index >= count) {
                    printf("Invalid index!\n");
                    break;
                }

                deleteline(&lines, index, &count, &capacity);
                printf("Line deleted!\n");
                break;


            case 4:
                if (count == 0) {
                    printf("No lines to show.\n");
                } else {
                    printf("\n--- STORED LINES ---\n");
                    print_all_lines(&lines, count);
                }
                break;


            case 5: {
                char filename[100];
                printf("Enter filename: ");
                fgets(filename, sizeof(filename), stdin);
                filename[strcspn(filename, "\n")] = '\0';

                FILE *fp = fopen(filename, "a");
                if (!fp) {
                    printf("Could not open file.\n");
                    break;
                }

                for (int i = 0; i < count; i++) {
                    fprintf(fp, "%s\n", lines[i]);
                }

                fclose(fp);
                printf("Saved to file!\n");
                break;
            }


            case 6:
                printf("Exiting...\n");

                
                for (int i = 0; i < count; i++)
                    free(lines[i]);
                free(lines);

                return 0;

            default:
                printf("Invalid choice.\n");
        }
    }
    return 0;
}